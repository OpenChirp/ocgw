Craig Hesling <craig@hesling.com>
August 11, 2016

This directory contains certificates used by the yodel gateway services.
The addtrustexternalcaroot.crt is used when connecting to CMU's WiFi or
eduroam with CMU credentials.
